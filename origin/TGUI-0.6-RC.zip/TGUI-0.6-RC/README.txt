TGUI - Texus's Graphical User Interface
=======================================

In one line: TGUI is an easy to use, cross-platform, c++ GUI for SFML.
For more information, take a look at the website (http://tgui.eu).



Download
--------

You can download the latest release on Github (https://github.com/texus/TGUI).

This download contains the latest development snapshot of TGUI v0.6.



Tutorials
---------

Tutorials can be found on my site (http://tgui.eu/tutorials/v06/).
You can also find example code there (http://tgui.eu/example-code/v06/).



About me
--------

Name:     Bruno Van de Velde
E-mail:   vdv_b@tgui.eu
Location: Belgium

